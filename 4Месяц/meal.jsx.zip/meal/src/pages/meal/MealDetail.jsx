import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
let urlDetail = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=";
const MealDetail = () => {
	const params = useParams();

	const [meal, setMeal] = useState(null);
	const ing = [];

	const navigate = useNavigate();

	useEffect(() => {
		const fetchMeal = async () => {
			const res = await fetch(urlDetail + params.id);
			const mealsData = await res.json();
			console.log(mealsData.meals[0]);
			setMeal(mealsData.meals[0]);
			for (let i = 1; i < 21; i++) {
				if (
					mealsData.meals[0][`strIngredient${i}`] !== null ||
					mealsData.meals[0][`strIngredient${i}`]?.length > 0
				) {
					console.log(mealsData.meals[0][`strIngredient${i}`]);
					ing.push(mealsData.meals[0][`strIngredient${i}`]);
				}
			}
			console.log(ing, "ingggggg");
		};

		fetchMeal();
	}, [params.id]);

	if (!meal) return <h2>Loading....</h2>;

	return (
		<div style={{ padding: "0px 30px" }}>
			<h1 className='text-center'>MealDetail Page</h1>
			<div className='d-flex gap-5'>
				<div>
					<h3>{meal.strMeal}</h3>
					<img width='250px' src={meal.strMealThumb} alt='' />
				</div>
				<div>
					<h3>Ingridients</h3>
					<div>
						{ing.length > 0 ? (
							ing?.map(img => {
								let imgUrl = "https://www.themealdb.com/images/ingredients";
								console.log(img, "ssss");
								return (
									<div>
										<img src={`${imgUrl}/${img}.png`} alt='' />
										<p>Ingridient Name</p>
									</div>
								);
							})
						) : (
							<p>sasa</p>
						)}
					</div>
				</div>
			</div>
			<div>
				<h1 className='text-center'>Instructions</h1>
				<div>{meal.strInstructions}</div>
			</div>
		</div>
	);
};

export default MealDetail;
