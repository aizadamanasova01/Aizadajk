import React from "react";

const About = () => {
	return <div>About PAGE</div>;
};

export default About;
