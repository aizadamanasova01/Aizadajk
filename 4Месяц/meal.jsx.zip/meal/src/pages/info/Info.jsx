import React from "react";

const Info = () => {
	return <div>Info PAGE</div>;
};

export default Info;
