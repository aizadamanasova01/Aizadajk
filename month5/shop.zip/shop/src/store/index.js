// TOOLKIT CONFIG
import { configureStore, createSlice } from "@reduxjs/toolkit";
const initState = {
	cart: [],
};

const cartSlice = createSlice({
	name: "cart",
	initialState: initState,
	reducers: {
		addItemToCart(state, action) {
			console.log(action, "add to cart");
			state.cart.push(action.payload); // action = {...}
		},
		removeItemInCart(state, action) {}, // dz (filter(el => el.id!==action.id))
	},
});

const store = configureStore(cartSlice);

export default store;

export const { addItemToCart } = cartSlice.actions;
