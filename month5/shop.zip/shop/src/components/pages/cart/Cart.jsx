import React from "react";
import { useSelector } from "react-redux";

import cartImg from "../../../assets/cart-img.png";

const Cart = () => {
	const cart = useSelector(store => store.cart);

	if (!cart.length) {
		return (
			<div className='cart-page'>
				<h3>The basket is empty 👀</h3>
				<h6>
					Most likely, you have not chosen anything. To order, go to the main
					page.
				</h6>
				<img src={cartImg} alt='' />
			</div>
		);
	}

	return (
		<div>
			<pre>{JSON.stringify(cart, null, 4)}</pre>
		</div>
	);
};

export default Cart;
